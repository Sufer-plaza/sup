package com.example.xftapp01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.xftapp01.Data.User;
import com.example.xftapp01.activity.Login;


import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.QueryListener;

public class MainActivity extends AppCompatActivity {

    private TextView username,nickname;

    private Button logout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Bmob.initialize(this,"11cfaa8f0a6bf17edabb8d4b5f87302a");
        logout = findViewById(R.id.logout);
        username = findViewById(R.id.username);
        nickname = findViewById(R.id.nickname);

        BmobUser user = BmobUser.getCurrentUser(User.class);
        String id = user.getObjectId();
        BmobQuery<User> myuser = new BmobQuery<User>();
        myuser.getObject(id, new QueryListener<User>() {
            @Override
            public void done(User user, BmobException e) {
                if(e ==null){
                    username.setText(user.getUsername());
                    nickname.setText(user.getNickname());
                }
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, Login.class));
            }
        });
    }
}
