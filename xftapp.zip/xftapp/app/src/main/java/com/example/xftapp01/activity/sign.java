package com.example.xftapp01.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.xftapp01.Data.User;
import com.example.xftapp01.MainActivity;
import com.example.xftapp01.R;

import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.SaveListener;

public class sign extends AppCompatActivity {

    private EditText username,password,nickname,second;
    private Button sign,back;




    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        nickname = findViewById(R.id.nickname);
        second = findViewById(R.id.second);
        sign = findViewById(R.id.sign);
        back = findViewById(R.id.back);
        //注册监听
        sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                User user = new User();
                user.setUsername(username.getText().toString().trim());
                user.setPassword(password.getText().toString().trim());
                user.setNickname(nickname.getText().toString().trim());
                
                if(username.getText().toString().equals(""))
                {
                    Toast.makeText(sign.this, "用户名没有输入", Toast.LENGTH_SHORT).show();
                }else if(password.getText().toString().equals("")){
                    Toast.makeText(sign.this, "密码没有输入", Toast.LENGTH_SHORT).show();
                }else if(second.getText().toString().equals(password.getText().toString())){

                    user.signUp(new SaveListener<User>() {
                        @Override
                        public void done(User o, BmobException e)
                        {
                            if(e==null){
                                Toast.makeText(sign.this, "注册成功", Toast.LENGTH_SHORT).show();
                                finish();
                            }else{
                                Toast.makeText(sign.this, "注册失败", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }

                else {

                    Toast.makeText(sign.this, "两次输入的密码不同", Toast.LENGTH_SHORT).show();
                }
            }
        });
        back.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                startActivity(new Intent(new Intent(sign.this,Login.class)));
            }
        });

    }
}
