package com.example.xftapp01;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.ashokvarma.bottomnavigation.BottomNavigationBar;
import com.ashokvarma.bottomnavigation.BottomNavigationItem;
import com.ashokvarma.bottomnavigation.behaviour.BottomNavBarFabBehaviour;
import com.example.xftapp01.Adapter.SectionsPagerAdapter;
import com.example.xftapp01.Data.User;
import com.example.xftapp01.Fragment.Fragmentcommunity;
import com.example.xftapp01.Fragment.Fragmentgame;
import com.example.xftapp01.Fragment.Fragmentmine;
import com.example.xftapp01.activity.Login;


import java.util.ArrayList;
import java.util.List;

import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.QueryListener;

public class MainActivity extends AppCompatActivity implements BottomNavigationBar.OnTabSelectedListener, ViewPager.OnPageChangeListener {

    private ViewPager viewPager;
    private BottomNavigationBar bottomNavigationBar;

    private List<Fragment> fragments;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Bmob.initialize(this,"11cfaa8f0a6bf17edabb8d4b5f87302a");
        viewPager = findViewById(R.id.ViewPager);
        bottomNavigationBar = findViewById(R.id.bottom);
        initView();
    }

    private void initView() {
        initViewPager();
        initBottomNavigation();
    }

    private void initBottomNavigation() {
        //配置底部导航栏
        bottomNavigationBar.setTabSelectedListener(this);
        bottomNavigationBar.clearAll();
        bottomNavigationBar.setMode(BottomNavigationBar.MODE_FIXED);
        bottomNavigationBar.setBackgroundStyle(BottomNavigationBar.BACKGROUND_STYLE_DEFAULT);
        bottomNavigationBar.setBarBackgroundColor(R.color.pink)
                            .setActiveColor(R.color.white)
                            .setInActiveColor(R.color.colorBase1);

        bottomNavigationBar.addItem(new BottomNavigationItem(R.drawable.mobilephone,"游戏，赛事").setInactiveIconResource(R.drawable.mobilephone_fill))
                .addItem(new BottomNavigationItem(R.drawable.order,"社区").setInactiveIconResource(R.drawable.order_fill))
                .addItem(new BottomNavigationItem(R.drawable.mine,"个人中心").setInactiveIconResource(R.drawable.mine_fill))
                .setFirstSelectedPosition(0)
                .initialise();

    }

    private void initViewPager() {
        //配置ViewPager
        viewPager.setOffscreenPageLimit(3);

        fragments = new ArrayList<Fragment>();
        fragments.add(new Fragmentgame());
        fragments.add(new Fragmentcommunity());
        fragments.add(new Fragmentmine());

        viewPager.setAdapter(new SectionsPagerAdapter(getSupportFragmentManager(),fragments));
        viewPager.addOnPageChangeListener(this);
        viewPager.setCurrentItem(0);

    }

    @Override
    public void onTabSelected(int position) {
        viewPager.setCurrentItem(position);
    }

    @Override
    public void onTabUnselected(int position) {

    }

    @Override
    public void onTabReselected(int position) {

    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        bottomNavigationBar.selectTab(position);

    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }
}
















        /*BmobUser user = BmobUser.getCurrentUser(User.class);
        String id = user.getObjectId();
        BmobQuery<User> myuser = new BmobQuery<User>();
        myuser.getObject(id, new QueryListener<User>() {
            @Override
            public void done(User user, BmobException e) {
                if(e ==null){

                }
            }
        });*/