package com.example.xftapp01.activity;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.xftapp01.MainActivity;
import com.example.xftapp01.R;

import java.util.Timer;
import java.util.TimerTask;

import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobUser;

public class splash extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        //延时操作
        Timer timer = new Timer();
        timer.schedule(timetast, 2000);

        Bmob.initialize(this,"11cfaa8f0a6bf17edabb8d4b5f87302a");

    }
        TimerTask timetast = new TimerTask() {
            @Override
            public void run() {
                //startActivity(new Intent(splash.this, MainActivity.class));
                //如果已登录跳转到主界面，否则跳转至登陆界面
                BmobUser bmobuser = BmobUser.getCurrentUser(BmobUser.class);
                if(bmobuser!=null)
                {
                    startActivity(new Intent(splash.this, MainActivity.class));
                    finish();
                }else{
                    //没有登陆
                    startActivity(new Intent(splash.this,Login.class));


                }



            }
        };

}
