package com.example.xftapp01.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.xftapp01.Data.User;
import com.example.xftapp01.MainActivity;
import com.example.xftapp01.R;
import com.example.xftapp01.activity.Login;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.QueryListener;
import cn.bmob.v3.listener.UpdateListener;

public class Fragmentmine extends Fragment {

    private EditText username,nickname,mobilePhoneNumber,email,city,signtext;

    private Button change,logout;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragementmine,container,false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initView();
        //加载我的信息
        getMyinform();


        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BmobUser.logOut();
                startActivity(new Intent(getActivity(), Login.class));
                getActivity().finish();

            }
        });
        change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BmobUser bu = BmobUser.getCurrentUser(BmobUser.class);
                String ID = bu.getObjectId();
                BmobQuery<User> bmobQuery = new BmobQuery<User>();
                bmobQuery.getObject(ID, new QueryListener<User>() {
                    @Override
                    public void done(User user, BmobException e) {


                        if(e==null){

                            if(mobilePhoneNumber.getText().length() != 11){
                                Toast.makeText(getActivity(),"请输入正确的手机号",Toast.LENGTH_SHORT).show();
                            }else if(email.getText().toString().contains("@")){
                                User user1 = new User();
                                user1.setNickname(nickname.getText().toString().trim());
                                user1.update(ID, new UpdateListener() {
                                    @Override
                                    public void done(BmobException e) {

                                        if(e==null){
                                            Toast.makeText(getActivity(),"更新成功",Toast.LENGTH_SHORT).show();
                                        }else{
                                            Toast.makeText(getActivity(),"更新失败",Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });
                                user1.setMobilePhoneNumber(mobilePhoneNumber.getText().toString().trim());
                                user1.update(ID, new UpdateListener() {
                                    @Override
                                    public void done(BmobException e) {

                                        if(e==null){
                                            Toast.makeText(getActivity(),"更新成功",Toast.LENGTH_SHORT).show();
                                        }else{
                                            Toast.makeText(getActivity(),"更新失败",Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });
                                user1.setEmail(email.getText().toString().trim());
                                user1.update(ID, new UpdateListener() {
                                    @Override
                                    public void done(BmobException e) {

                                        if(e==null){
                                            Toast.makeText(getActivity(),"更新成功",Toast.LENGTH_SHORT).show();
                                        }else{
                                            Toast.makeText(getActivity(),"更新失败",Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });
                                user1.setCity(city.getText().toString().trim());
                                user1.update(ID, new UpdateListener() {
                                    @Override
                                    public void done(BmobException e) {

                                        if(e==null){
                                            Toast.makeText(getActivity(),"更新成功",Toast.LENGTH_SHORT).show();
                                        }else{
                                            Toast.makeText(getActivity(),"更新失败",Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });
                                user1.setSigntext(signtext.getText().toString().trim());
                                user1.update(ID, new UpdateListener() {
                                    @Override
                                    public void done(BmobException e) {

                                        if(e==null){
                                            Toast.makeText(getActivity(),"更新成功",Toast.LENGTH_SHORT).show();
                                        }else{
                                            Toast.makeText(getActivity(),"更新失败",Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });

                            }else{
                                Toast.makeText(getActivity(),"请输入正确的邮箱",Toast.LENGTH_SHORT).show();
                            }


                        }else{
                            Toast.makeText(getActivity(),"修改失败",Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });

    }
    private void getMyinform() {
        //加载个人信息
        BmobUser bu = BmobUser.getCurrentUser(BmobUser.class);
        String ID = bu.getObjectId();
        BmobQuery<User> bmobQuery = new BmobQuery<User>();
        bmobQuery.getObject(ID, new QueryListener<User>() {
            @Override
            public void done(User user, BmobException e) {
                if(e==null){
                    username.setText(user.getUsername());
                    nickname.setText(user.getNickname());
                    mobilePhoneNumber.setText(user.getMobilePhoneNumber());
                    email.setText(user.getEmail());
                    city.setText(user.getCity());
                    if(user.getSigntext() == null){
                        signtext.setText("这个用户很懒什么也没写~");
                    }else{
                        signtext.setText(user.getSigntext());
                    }

                }else{
                    Toast.makeText(getActivity(),"加载失败",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    private void initView() {
        username = getActivity().findViewById(R.id.username);
        nickname = getActivity().findViewById(R.id.nickname);
        mobilePhoneNumber = getActivity().findViewById(R.id.mobilePhoneNumber);
        email = getActivity().findViewById(R.id.email);
        city = getActivity().findViewById(R.id.city);
        logout = getActivity().findViewById(R.id.logout);
        change = getActivity().findViewById(R.id.change);
        signtext = getActivity().findViewById(R.id.signtext);
    }



}
