package com.example.xftapp01.Data;

import cn.bmob.v3.BmobUser;

public class User extends BmobUser {

    private  String nickname;
    private  String city;
    private  String signtext;

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;

    }


    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getSigntext() {
        return signtext;
    }

    public void setSigntext(String signtext) {
        this.signtext = signtext;
    }
}
